<script setup>
import { reactive, computed } from 'vue';

const data = reactive({
  number: 0,
  temp: 0,
  operater: null,
})

function inputnumber(number) {

  //값이 0일때
  //data.number = number

  // 값이 쌓임 = 누적 연산 x
  // if(data.number == 0) data.number = number
  // else data.number = data.number * 10 + number

  if(data.number == 0) data.number = number
  else data.number = data.number * 10 + number
}

// 연산기호
function inputOperater(value){
  data.temp = data.number
  data.number = 0
  data.operater = value
}

// 연산
const displayed = computed(() => {
  let text = ''
  if(data.temp) text += data.temp
  if(data.operater) text += data.operater
  if(data.number) text += data.number
  if(!text) text = 0
  return text
})

// 최종값
function calculate () {
  // 값 확인
  // alert(eval(displayed.value));
  let result = eval(displayed.value)
  data.temp = 0
  data.operater = null
  data.number = result
}

function reset(){
  data.temp = 0
  data.operater = null
  data.number = 0
}
</script>

<template>  

<!--data temp값 확인용 -->
  <!-- <div>{{ data }}</div> -->
  <!--grid 새로 -->
  <div class="grid grid-cols-4 gap-4">

    <div class="col-span-4 border p-4 text-right rounded-lg bg-black text-white">
      <!-- {{ data.temp }} {{ data.number }} {{ data.operater }} -->
      <!-- {{ displayed }} -->
    </div>

    <div class="col-span-3 grid grid-cols-3 gap-4">
      <!--n = 1~9-->
      <button v-for="n of 9" @click="inputnumber(n)">{{ n }}</button>
      <button @click="inputnumber(0)">0</button>
      <button @click="reset">C</button>
      <button @click="calculate">=</button>
    </div>

    <div class="col-span-1 grid gap-4">
        <button v-for="o of ['+','-','*','/']" @click="inputOperater(o)">{{ o }}</button>
    </div>
   <!-- 
        기본적인 세팅
        <div class="col-span-1 grid gap-4">
        <button @click="inputOperater('+')">+</button>
        <button>-</button>
        <button>*</button>
        <button>/</button>
    </div>-->
  </div>
</template>